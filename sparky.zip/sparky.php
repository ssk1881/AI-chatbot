<html>
<head>
<title>
Sparky
</title>
</head>	
<body><center>
	<h1>Sparky - Self learning A.I chatbot</h1>
	<br>
<form action="/cgi-bin/sparky.py" method="get">
Sparky:<textarea name="sparky" cols=40 rows=4>hai..!</textarea><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
_sree_:<textarea name="user" cols=40 rows=4></textarea>
<input type="submit" value="Send" />
</form>
</center>
</body>
</html>
